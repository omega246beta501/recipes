<?php
    use App\Data\Routes\MenuRoutes;
    use App\Data\Routes\RecipeRoutes;
?>
<table class="table table-hover table-dark" id="recipestable">
    <thead>
        <tr>
            <th>#</th>
            <th>Receta</th>
            <?php if($isMenuSet): ?>
            <th>En el menú</th>
            <?php else: ?>
            <th>Mantener?</th>
            <?php endif; ?>
        </tr>
    </thead>
    <?php $__currentLoopData = $recipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recipe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <th><?php echo e($recipe->id); ?></th>
        <th><a href="<?php echo e(str_replace('{id}', $recipe->id, RecipeRoutes::RECIPE)); ?>"><?php echo e($recipe->name); ?></a></th>
        <?php if($isMenuSet): ?>
        <th><input class="form-check-input keeped" type="checkbox" value="" id="<?php echo e($recipe->id); ?>" checked disabled></th>
        <?php else: ?>
        <th><input class="form-check-input keeped" type="checkbox" value="" id="<?php echo e($recipe->id); ?>" <?php if(isset($keepedRecipesIds) && in_array($recipe->id, $keepedRecipesIds)): echo 'checked'; endif; ?>></th>
        <?php endif; ?>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table><?php /**PATH /var/www/html/resources/views/components/menu/table.blade.php ENDPATH**/ ?>