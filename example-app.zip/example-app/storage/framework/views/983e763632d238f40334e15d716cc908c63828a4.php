<div class="row row-cols-1 row-cols-md-4 g-4">
    <?php $__currentLoopData = $attachedIngredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col">
        <div class="card">
            <div class="card-header text-center bg-danger bg-gradient bg-opacity-75" onclick="detachRecipeFromIngredient(event, <?php echo e($recipe->id); ?>, <?php echo e($ingredient->id); ?>)">
                <?php echo e($ingredient->name); ?>

            </div>
            <div class="card-body">
                <input id="<?php echo e($recipe->id); ?>-<?php echo e($ingredient->id); ?>" class="form-control mb-2 text-center" type="text" placeholder="Cantidad, descripción..." value="<?php echo e($ingredient->pivot->description); ?>">
                <div class="row">
                    <div class="col"></div>
                    <div class="col">
                        <button class="btn btn-success" onclick="updateAttachedIngredient(<?php echo e($recipe->id); ?>, <?php echo e($ingredient->id); ?>)">Update</button>
                    </div>
                    <div class="col"></div>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="col">
        <div class="card">
            <div class="card-header text-center">
                <input id="autocomplete" class="form-control mb-2 text-center" type="text" placeholder="Ingrediente" autocomplete="off">
            </div>
            <div class="card-body">
                <input id="newIngredientDescription" class="form-control mb-2 text-center" type="text" placeholder="Cantidad, descripción...">
                <div class="row">
                    <div class="col"></div>
                    <div class="col">
                        <button class="btn btn-primary" onclick="addNewIngredient(<?php echo e($recipe->id); ?>)">Añadir</button>
                    </div>
                    <div class="col"></div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH /var/www/html/resources/views/components/ingredients/grid.blade.php ENDPATH**/ ?>