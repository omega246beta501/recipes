<?php
use App\Data\Routes\MenuRoutes;
?>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layout','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Menú <?php $__env->endSlot(); ?>
        <div class="container">
            <div class="row">
                <div class="col">
                </div>
                <div class="col">
                    <div class="row">
                        <div class="regenerable col">
                            <?php if (isset($component)) { $__componentOriginalc57526945d527463e6847ee355039ddc06349dd1 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Menu\Table::class, ['isMenuSet' => $isMenuSet,'recipes' => $recipes] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('menu.table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Menu\Table::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc57526945d527463e6847ee355039ddc06349dd1)): ?>
<?php $component = $__componentOriginalc57526945d527463e6847ee355039ddc06349dd1; ?>
<?php unset($__componentOriginalc57526945d527463e6847ee355039ddc06349dd1); ?>
<?php endif; ?>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <select id="includedCategoriesSelect" name="kk[]" multiple="multiple" style="width: 100%;">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value=<?php echo e($category->id); ?>><?php echo e($category->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="row">
                            <div class="col">
                                <select id="excludedCategoriesSelect" name="states[]" multiple="multiple" style="width: 100%;">
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value=<?php echo e($category->id); ?>><?php echo e($category->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <button type="submit" <?php if($isMenuSet): echo 'disabled'; endif; ?> class="btn btn-danger" onclick="regenerate()">Regenerar recetas</button>
                        </div>
                        <div class="col">
                            <button type="submit" <?php if($isMenuSet): echo 'disabled'; endif; ?> class="btn btn-primary" onclick="includeInMenu()">Asignar menú</button>
                        </div>
                    </div>
                    <?php if($isMenuSet): ?>
                    <div class="row">
                        <div class="col">
                            <button class="btn btn-warning" onclick="newMenu()">Nuevo Menú</button>
                        </div>
                        <div class="col">
                            <button type="submit" class="btn btn-warning" onclick="clearMenu()">Reiniciar menú</button>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="col">
                </div>
            </div>
        </div>
        <script>
            $(document).ready(function() {
                $('#includedCategoriesSelect').select2({
                    width: 'resolve',
                    placeholder: "Categorías a incluir"
                });
                $('#excludedCategoriesSelect').select2({
                    width: 'resolve',
                    placeholder: "Categorías a excluir"
                });
            });

            function regenerate() {
                var selectedToKeepIds = [];
                var includedCategories = [];
                var excludedCategories = [];

                $('#recipestable input:checked').each(function() {
                    selectedToKeepIds.push($(this).attr('id'));
                });

                $('#includedCategoriesSelect').find(':selected').each(function() {
                    includedCategories.push(this.value);
                });

                $('#excludedCategoriesSelect').find(':selected').each(function() {
                    excludedCategories.push(this.value);
                });

                var data = {
                    "keepedRecipesIds": selectedToKeepIds,
                    "includedCategoriesIds": includedCategories,
                    "excludedCategoriesIds": excludedCategories
                }

                var settings = {
                    "async": true,
                    "crossDomain": true,
                    "url": "<?php echo e(MenuRoutes::REGENERATE_RECIPES); ?>",
                    "method": "POST",
                    "headers": {
                        "cache-control": "no-cache",
                        "postman-token": "beeffe31-037f-448b-b45a-382e3b7c8e1c"
                    },
                    "data": JSON.stringify(data)
                }

                $.ajax(settings).done(function(response) {
                    $(".regenerable").html(response);
                });
            }

            function includeInMenu() {

                var selectedToInsert = [];

                $('#recipestable input:checkbox').each(function() {
                    selectedToInsert.push($(this).attr('id'));
                });

                var data = {
                    "recipesToInclude": selectedToInsert
                }

                var settings = {
                    "async": true,
                    "crossDomain": true,
                    "url": "<?php echo e(MenuRoutes::CREATE_MENU); ?>",
                    "method": "POST",
                    "headers": {
                        "cache-control": "no-cache",
                        "postman-token": "beeffe31-037f-448b-b45a-382e3b7c8e1c"
                    },
                    "data": JSON.stringify(data)
                }

                $.ajax(settings).done(function(response) {
                    alert('Se ha generado el menu para la semana');
                    location.reload();
                });
            }

            function clearMenu() {

                var settings = {
                    "async": true,
                    "crossDomain": true,
                    "url": "<?php echo e(MenuRoutes::DISCARD_MENU); ?>",
                    "method": "GET",
                    "headers": {
                        "cache-control": "no-cache",
                        "postman-token": "beeffe31-037f-448b-b45a-382e3b7c8e1c"
                    }
                }
                response = confirm("¿Estás seguro de querer borrar el menú?");

                if (response) {
                    $.ajax(settings).done(function(response) {
                        alert('Se ha borrado el menú de la semana. Las recetas no utilizadas vuelven a estar disponibles.');
                        location.reload();
                    });
                }
            }

            function newMenu() {

                var settings = {
                    "async": true,
                    "crossDomain": true,
                    "url": "<?php echo e(MenuRoutes::NEW_MENU); ?>",
                    "method": "GET",
                    "headers": {
                        "cache-control": "no-cache",
                        "postman-token": "beeffe31-037f-448b-b45a-382e3b7c8e1c"
                    }
                }
                response = confirm("¿Estás seguro de querer archivar el menú actual?");

                if (response) {
                    $.ajax(settings).done(function(response) {
                        alert('El antiguo menu ha sido archivado. Ahora puedes crear un nuevo menú');
                        location.reload();
                    });
                }
            }
        </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH /var/www/html/resources/views/menu.blade.php ENDPATH**/ ?>