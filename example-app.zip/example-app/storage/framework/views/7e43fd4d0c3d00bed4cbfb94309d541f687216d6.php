<?php
$categoryCounter = 1;
use App\Data\Routes\CategoryRoutes;
?>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layout','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Categorías <?php $__env->endSlot(); ?>
        <div class="container">
            <div class="row" style="margin-bottom: 1%;">
                <div class="col"></div>
                <div class="col-6">
                    <?php if (isset($component)) { $__componentOriginal9ee3ccba9b33c7fd4e2dff836fa0d217a344c5d4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Elements\Accordion::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('elements.accordion'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Elements\Accordion::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                         <?php $__env->slot('buttonName', null, []); ?> 
                            Insertar nueva categoría
                         <?php $__env->endSlot(); ?>
                         <?php $__env->slot('accordionButtonId', null, []); ?> 
                            newCategoryAccordionButton
                         <?php $__env->endSlot(); ?>
                         <?php $__env->slot('accordionId', null, []); ?> 
                            newCategoryAccordion
                         <?php $__env->endSlot(); ?>
                        <?php if (isset($component)) { $__componentOriginalbf253df6c07827abb85405b3e9fa0c400e6de284 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Forms\Category::class, ['recipes' => $recipes] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('forms.category'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Forms\Category::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbf253df6c07827abb85405b3e9fa0c400e6de284)): ?>
<?php $component = $__componentOriginalbf253df6c07827abb85405b3e9fa0c400e6de284; ?>
<?php unset($__componentOriginalbf253df6c07827abb85405b3e9fa0c400e6de284); ?>
<?php endif; ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ee3ccba9b33c7fd4e2dff836fa0d217a344c5d4)): ?>
<?php $component = $__componentOriginal9ee3ccba9b33c7fd4e2dff836fa0d217a344c5d4; ?>
<?php unset($__componentOriginal9ee3ccba9b33c7fd4e2dff836fa0d217a344c5d4); ?>
<?php endif; ?>
                </div>
                <div class="col"></div>
            </div>
            <div class="row">
                <div class="col">
                </div>
                <div class="col">
                    <div class="row">
                        <div class="regenerable col">
                            <table class="table table-hover table-dark" id="recipestable">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Categoría</th>
                                        <th>Cantidad</th>
                                    </tr>
                                </thead>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($categoryCounter); ?></td>
                                    <td><a onclick="openModal('updateModal', <?php echo e($category->id); ?>)"><?php echo e($category->name); ?></a></td>
                                    <!-- <td><a href="<?php echo e(str_replace('{id}', $category->id, App\Data\Routes\CategoryRoutes::RECIPES_BY_CATEGORY)); ?>"><?php echo e($category->name); ?></a></td> -->
                                    <td><?php echo e($category->recipes_count); ?></td>
                                </tr>
                                <?php $categoryCounter++; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col">
                </div>
            </div>
        </div>
        <div class="modalContainer">
            <?php if (isset($component)) { $__componentOriginal63928065a0b1057c79059c1e5a8dd5cc0015c5e6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Elements\Modal::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('elements.modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Elements\Modal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                 <?php $__env->slot('modalId', null, []); ?> updateModal <?php $__env->endSlot(); ?>
                 <?php $__env->slot('title', null, []); ?> Actualizar Categoría <?php $__env->endSlot(); ?>
                <!-- Al hacer una peticion al controller, este renderizara el form -->
                <div id="updateCategoryForm"></div>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal63928065a0b1057c79059c1e5a8dd5cc0015c5e6)): ?>
<?php $component = $__componentOriginal63928065a0b1057c79059c1e5a8dd5cc0015c5e6; ?>
<?php unset($__componentOriginal63928065a0b1057c79059c1e5a8dd5cc0015c5e6); ?>
<?php endif; ?>
        </div>
        <script>
            $(document).ready(function() {
                $('#insertRecipesSelect').select2({
                    width: 'resolve',
                    placeholder: "Recetas a incluir"
                });
            });

            function openModal(modalId, recipeId) {

                var settings = {
                    "async": true,
                    "crossDomain": true,
                    "url": "<?php echo e(CategoryRoutes::UPDATE_VIEW); ?>".replace("{id}", recipeId),
                    "method": "GET",
                    "headers": {
                        "cache-control": "no-cache",
                        "postman-token": "beeffe31-037f-448b-b45a-382e3b7c8e1c"
                    }
                }

                $.ajax(settings).done(function(response) {
                    $("#updateCategoryForm").html(response);
                    // Select2 situado en el formulario que general el controller. Metodo UpdateView
                    $('#updateRecipesSelect').select2({
                        width: 'resolve',
                        placeholder: "Categorías a incluir (Opcional)",
                        dropdownParent: $('#' + modalId)
                    });
                });

                $('#' + modalId).modal('show');
            }
        </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH /var/www/html/resources/views/categories.blade.php ENDPATH**/ ?>