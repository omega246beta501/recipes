<div class="modal fade" data-bs-backdrop="static" tabindex="-1" role="dialog" id="<?php echo e($modalId); ?>">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><?php echo e($title); ?></h5>
                <button type="button" class="closeModalButton close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="container-fluid">
                    <?php echo e($slot); ?>

                </div>
            </div>
            <!-- <div class="modal-footer">
                <button type="button" class="closeModalButton btn btn-secondary" data-dismiss="modal">Close</button>
            </div> -->
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        $('.closeModalButton').click(function() {
            $('#<?php echo e($modalId); ?>').modal('hide');
        });

        $("body").on("mousedown", function(e) {
            if($(e.target).attr('class') == 'modal fade show') {
                $('#<?php echo e($modalId); ?>').modal('hide');
            }
        });
    });
</script><?php /**PATH /var/www/html/resources/views/components/elements/modal.blade.php ENDPATH**/ ?>