<?php
$recipeCounter = 1;
use App\Data\Routes\MenuRoutes;
use App\Data\Routes\RecipeRoutes;
?>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layout','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Recetas <?php $__env->endSlot(); ?>
        <div class="container">
            <div class="row" style="margin-bottom: 1%;">
                <div class="col"></div>
                <div class="col-6">
                    <?php if (isset($component)) { $__componentOriginal9ee3ccba9b33c7fd4e2dff836fa0d217a344c5d4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Elements\Accordion::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('elements.accordion'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Elements\Accordion::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                         <?php $__env->slot('buttonName', null, []); ?> 
                            Insertar nueva receta
                         <?php $__env->endSlot(); ?>
                         <?php $__env->slot('accordionButtonId', null, []); ?> 
                            newRecipeAccordionButton
                         <?php $__env->endSlot(); ?>
                         <?php $__env->slot('accordionId', null, []); ?> 
                            newRecipeAccordion
                         <?php $__env->endSlot(); ?>
                        <?php if (isset($component)) { $__componentOriginal3f49f81160c6367a105c7bf423c5940f74427e42 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Forms\Recipe::class, ['categories' => $categories] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('forms.recipe'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Forms\Recipe::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3f49f81160c6367a105c7bf423c5940f74427e42)): ?>
<?php $component = $__componentOriginal3f49f81160c6367a105c7bf423c5940f74427e42; ?>
<?php unset($__componentOriginal3f49f81160c6367a105c7bf423c5940f74427e42); ?>
<?php endif; ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ee3ccba9b33c7fd4e2dff836fa0d217a344c5d4)): ?>
<?php $component = $__componentOriginal9ee3ccba9b33c7fd4e2dff836fa0d217a344c5d4; ?>
<?php unset($__componentOriginal9ee3ccba9b33c7fd4e2dff836fa0d217a344c5d4); ?>
<?php endif; ?>
                </div>
                <div class="col"></div>
            </div>
            <div class="row">
                <div class="col">
                </div>
                <div class="col">
                    <div class="row">
                        <div class="col">
                            <table class="table table-hover table-dark">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th><?php echo e($tableTitle); ?></th>
                                        <th>Última vez</th>
                                    </tr>
                                </thead>
                                <?php $__currentLoopData = $recipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recipe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($recipeCounter); ?></td>
                                    <td><a onclick="openModal('updateModal', <?php echo e($recipe->id); ?>)"><?php echo e($recipe->name); ?></a></td>
                                    <td><?php echo e($recipe->last_used_at); ?></td>
                                </tr>
                                <?php $recipeCounter++; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="col">
                </div>
            </div>
        </div>
        <div class="modalContainer">
            <?php if (isset($component)) { $__componentOriginal63928065a0b1057c79059c1e5a8dd5cc0015c5e6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Elements\Modal::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('elements.modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Elements\Modal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                 <?php $__env->slot('modalId', null, []); ?> updateModal <?php $__env->endSlot(); ?>
                 <?php $__env->slot('title', null, []); ?> Actualizar Receta <?php $__env->endSlot(); ?>
                <!-- Al hacer una peticion al controller, este renderizara el form -->
                <div id="updateRecipeForm"></div>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal63928065a0b1057c79059c1e5a8dd5cc0015c5e6)): ?>
<?php $component = $__componentOriginal63928065a0b1057c79059c1e5a8dd5cc0015c5e6; ?>
<?php unset($__componentOriginal63928065a0b1057c79059c1e5a8dd5cc0015c5e6); ?>
<?php endif; ?>
        </div>
        <script>
            $(document).ready(function() {
                $('#insertSelec2Categories').select2({
                    width: 'resolve',
                    placeholder: "Categorías a incluir (Opcional)"
                });
            });

            function openModal(modalId, recipeId) {

                var settings = {
                    "async": true,
                    "crossDomain": true,
                    "url": "<?php echo e(RecipeRoutes::UPDATE_VIEW); ?>".replace("{id}", recipeId),
                    "method": "GET",
                    "headers": {
                        "cache-control": "no-cache",
                        "postman-token": "beeffe31-037f-448b-b45a-382e3b7c8e1c"
                    }
                }

                $.ajax(settings).done(function(response) {
                    $("#updateRecipeForm").html(response);
                    // Select2 situado en el formulario que general el controller. Metodo UpdateView
                    $('#updateSelec2Categories').select2({
                        width: 'resolve',
                        placeholder: "Categorías a incluir (Opcional)",
                        dropdownParent: $('#' + modalId)
                    });
                });

                $('#' + modalId).modal('show');
            }
        </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH /var/www/html/resources/views/recipes.blade.php ENDPATH**/ ?>