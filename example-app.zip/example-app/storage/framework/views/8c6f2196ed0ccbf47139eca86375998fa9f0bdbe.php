<!-- Formulario de recetas -->
<?php
use Illuminate\Database\Eloquent\Collection;
use App\Data\Routes\RecipeRoutes;
use App\Data\Routes\IngredientRoutes;

if(!isset($attachedCategories)) {
$attachedCategories = new Collection();
}

if(!isset($attachedIngredients)) {
$attachedIngredients = new Collection();
}

$formMode = "insert";
if(isset($recipe)) {
$formMode = "update";
}

?>
<div class="recipeForm">
    <div class="row">
        <div class="col">
            <input class="form-control" type="text" id="<?php echo e($formMode); ?>RecipeName" placeholder="Nombre" <?php if(isset($recipe)): ?> value="<?php echo e($recipe->name); ?>" <?php endif; ?>>
        </div>
        <div class="col">
            <select class="form-control" id="<?php echo e($formMode); ?>Selec2Categories" name="kk[]" multiple="multiple" style="width: 100%;">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value=<?php echo e($category->id); ?> <?php if($attachedCategories->contains($category)): echo 'selected'; endif; ?>><?php echo e($category->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
    <div class="row">
        <div class="col">
            <input class="form-control" type="text" id="<?php echo e($formMode); ?>RecipePrice" placeholder="Precio (Opcional)" <?php if(isset($recipe)): ?> value="<?php echo e($recipe->price); ?>" <?php endif; ?>>
        </div>
        <div class="col">
            <input class="form-control" type="text" id="<?php echo e($formMode); ?>RecipeKcal" placeholder="Calorías (Opcional)" <?php if(isset($recipe)): ?> value="<?php echo e($recipe->kcal); ?>" <?php endif; ?>>
        </div>
    </div>
    <?php if($formMode == 'update'): ?>
    <div class="row">
        <div class="col-12">
            <?php if (isset($component)) { $__componentOriginal9ee3ccba9b33c7fd4e2dff836fa0d217a344c5d4 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Elements\Accordion::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('elements.accordion'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Elements\Accordion::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                 <?php $__env->slot('buttonName', null, []); ?> 
                    Ingredientes
                 <?php $__env->endSlot(); ?>
                 <?php $__env->slot('accordionButtonId', null, []); ?> 
                    <?php if($formMode == 'insert'): ?>
                    newIngredientsAccordionButton
                    <?php else: ?>
                    updateIngredientsAccordionButton
                    <?php endif; ?>
                 <?php $__env->endSlot(); ?>
                 <?php $__env->slot('accordionId', null, []); ?> 
                    <?php if($formMode == 'insert'): ?>
                    newIngredientsAccordion
                    <?php else: ?>
                    updateIngredientsAccordion
                    <?php endif; ?>
                 <?php $__env->endSlot(); ?>
                <div id="ingredientsGrid">
                    <div class="row row-cols-1 row-cols-md-4 g-4">
                        <?php $__currentLoopData = $attachedIngredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col">
                            <div class="card">
                                <div class="card-header text-center bg-danger bg-gradient bg-opacity-75" onclick="detachRecipeFromIngredient(event, <?php echo e($recipe->id); ?>, <?php echo e($ingredient->id); ?>)">
                                    <?php echo e($ingredient->name); ?>

                                </div>
                                <div class="card-body">
                                    <input id="<?php echo e($recipe->id); ?>-<?php echo e($ingredient->id); ?>" class="form-control mb-2 text-center" type="text" placeholder="Cantidad, descripción..." value="<?php echo e($ingredient->pivot->description); ?>">
                                    <div class="row">
                                        <div class="col"></div>
                                        <div class="col">
                                            <button class="btn btn-success" onclick="updateAttachedIngredient(<?php echo e($recipe->id); ?>, <?php echo e($ingredient->id); ?>)">Update</button>
                                        </div>
                                        <div class="col"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="col">
                            <div class="card">
                                <div class="card-header text-center">
                                    <input id="autocomplete" class="form-control mb-2 text-center" type="text" placeholder="Ingrediente" autocomplete="off">
                                </div>
                                <div class="card-body">
                                    <input id="newIngredientDescription" class="form-control mb-2 text-center" type="text" placeholder="Cantidad, descripción...">
                                    <div class="row">
                                        <div class="col"></div>
                                        <div class="col">
                                            <button class="btn btn-primary" onclick="addNewIngredient(<?php echo e($recipe->id); ?>)">Añadir</button>
                                        </div>
                                        <div class="col"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ee3ccba9b33c7fd4e2dff836fa0d217a344c5d4)): ?>
<?php $component = $__componentOriginal9ee3ccba9b33c7fd4e2dff836fa0d217a344c5d4; ?>
<?php unset($__componentOriginal9ee3ccba9b33c7fd4e2dff836fa0d217a344c5d4); ?>
<?php endif; ?>
        </div>
    </div>
    <?php endif; ?>
    <div class="row">
        <div class="col-12">
            <textarea class="form-control" id="<?php echo e($formMode); ?>RecipeDescription" cols="30" rows="10" placeholder="Descripción de la receta (Opcional)"><?php if(isset($recipe)): ?><?php echo e($recipe->description); ?><?php endif; ?></textarea>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <input class="form-control" id="<?php echo e($formMode); ?>RecipeUrl" placeholder="Url vídeo de la receta (Opcional)" <?php if(isset($recipe)): ?> value="<?php echo e($recipe->url); ?>"<?php endif; ?>>
        </div>
    </div>
    <?php if(isset($recipe) && isset($recipe->url)): ?>
    <div class="row">
        <div class="col">
            <div class="embed-responsive embed-responsive-16by9">
                <iframe class="embed-responsive-item" width="100%" height="400" src="<?php echo e($recipe->url); ?>" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <div class="row" style="margin-top: 2%;">
        <div class="col-10"></div>
        <div class="col">
            <?php if(isset($recipe)): ?>
            <button class="btn btn-success" onclick="updateRecipe(<?php echo e($recipe->id); ?>)">Actualizar</button>
            <?php else: ?>
            <button class="btn btn-success" onclick="createRecipe()">Crear</button>
            <?php endif; ?>
        </div>
    </div>
</div>
<script src="//code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script>
    function createRecipe() {
        var categoriesToAttach = [];
        var recipeName = $('#insertRecipeName').val();
        var recipePrice = $('#insertRecipePrice').val();
        var recipeKcal = $('#insertRecipeKcal').val();
        var recipeDescription = $('#insertRecipeDescription').val();
        var recipeUrl = $('#insertRecipeUrl').val();

        $('#insertSelec2Categories').find(':selected').each(function() {
            categoriesToAttach.push(this.value);
        });

        var data = {
            "categoriesToAttach": categoriesToAttach,
            "newName": recipeName,
            "newPrice": recipePrice,
            "newKcal": recipeKcal,
            "newDescription": recipeDescription,
            "newUrl": recipeUrl
        }

        var settings = {
            "async": true,
            "crossDomain": true,
            "url": "<?php echo e(RecipeRoutes::NEW_RECIPE); ?>",
            "method": "POST",
            "headers": {
                "cache-control": "no-cache",
                "postman-token": "beeffe31-037f-448b-b45a-382e3b7c8e1c"
            },
            "data": JSON.stringify(data)
        }

        $.ajax(settings).done(function(response) {
            alert('Se ha incluido una receta nueva al sistema');
            location.reload();
        });
    }

    function updateRecipe(id) {
        var categoriesToAttach = [];
        var recipeName = $('#updateRecipeName').val();
        var recipePrice = $('#updateRecipePrice').val();
        var recipeKcal = $('#updateRecipeKcal').val();
        var recipeDescription = $('#updateRecipeDescription').val();
        var recipeUrl = $('#updateRecipeUrl').val();

        $('#updateSelec2Categories').find(':selected').each(function() {
            categoriesToAttach.push(this.value);
        });

        var data = {
            "categoriesToAttach": categoriesToAttach,
            "newName": recipeName,
            "newPrice": recipePrice,
            "newKcal": recipeKcal,
            "newDescription": recipeDescription,
            "newUrl": recipeUrl,
            "id": id
        }

        var settings = {
            "async": true,
            "crossDomain": true,
            "url": "<?php echo e(RecipeRoutes::UPDATE); ?>",
            "method": "POST",
            "headers": {
                "cache-control": "no-cache",
                "postman-token": "beeffe31-037f-448b-b45a-382e3b7c8e1c"
            },
            "data": JSON.stringify(data)
        }

        $.ajax(settings).done(function(response) {
            alert('Se ha actualizado la receta en el sistema');
        });
    }

    function addNewIngredient(recipeId) {

        var newIngredientName = $('#autocomplete').val();
        var newIngredientDescription = $('#newIngredientDescription').val();

        var data = {
            "recipeId": recipeId,
            "newIngredientName": newIngredientName,
            "newIngredientDescription": newIngredientDescription,
        }

        var settings = {
            "async": true,
            "crossDomain": true,
            "url": "<?php echo e(IngredientRoutes::ATTACH_RECIPE); ?>",
            "method": "POST",
            "headers": {
                "cache-control": "no-cache",
                "postman-token": "beeffe31-037f-448b-b45a-382e3b7c8e1c"
            },
            "data": JSON.stringify(data)
        }

        $.ajax(settings).done(function(response) {
            $("#ingredientsGrid").html(response);

            $("#autocomplete").autocomplete({
                source: "<?php echo e(IngredientRoutes::QUERY_INGREDIENTS); ?>"
            });
        });
    }

    function detachRecipeFromIngredient(event, recipeId, ingredientId) {

        var data = {
            "recipeId": recipeId,
            "ingredientId": ingredientId,
        }

        var settings = {
            "async": true,
            "crossDomain": true,
            "url": "<?php echo e(IngredientRoutes::DETACH_RECIPE); ?>",
            "method": "POST",
            "headers": {
                "cache-control": "no-cache",
                "postman-token": "beeffe31-037f-448b-b45a-382e3b7c8e1c"
            },
            "data": JSON.stringify(data)
        }

        detach = true;

        if (event.ctrlKey == false) {
            detach = confirm("¿Deseas eliminar el ingrediente de la receta?");
        }

        if (detach) {
            $.ajax(settings).done(function(response) {
                $("#ingredientsGrid").html(response);

                $("#autocomplete").autocomplete({
                    source: "<?php echo e(IngredientRoutes::QUERY_INGREDIENTS); ?>"
                });
            });
        }
    }

    function updateAttachedIngredient(recipeId, ingredientId) {

        description = $("#" + recipeId + "-" + ingredientId).val();

        var data = {
            "recipeId": recipeId,
            "ingredientId": ingredientId,
            "description": description
        }

        var settings = {
            "async": true,
            "crossDomain": true,
            "url": "<?php echo e(IngredientRoutes::UPDATE_ATTACHED); ?>",
            "method": "POST",
            "headers": {
                "cache-control": "no-cache",
                "postman-token": "beeffe31-037f-448b-b45a-382e3b7c8e1c"
            },
            "data": JSON.stringify(data)
        }

        $.ajax(settings).done(function(response) {
            $("#ingredientsGrid").html(response);

            $("#autocomplete").autocomplete({
                source: "<?php echo e(IngredientRoutes::QUERY_INGREDIENTS); ?>"
            });
            alert('Se ha actualizado el ingrediente en el sistema');
        });
    }

    $(document).ready(function() {
        $("#autocomplete").autocomplete({
            source: "<?php echo e(IngredientRoutes::QUERY_INGREDIENTS); ?>"
        });
    });
</script><?php /**PATH /var/www/html/resources/views/components/forms/recipe.blade.php ENDPATH**/ ?>