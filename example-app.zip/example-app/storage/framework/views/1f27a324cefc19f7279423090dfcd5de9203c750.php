<?php
use Illuminate\Database\Eloquent\Collection;
use App\Data\Routes\RecipeRoutes;
use App\Data\Routes\CategoryRoutes;

if(!isset($attachedRecipes)) {
$attachedRecipes = new Collection();
}

$formMode = "insert";
if(isset($category)) {
$formMode = "update";
}

?>
<div class="categoryForm">
    <div class="row">
        <div class="col">
            <input class="form-control" type="text" id="<?php echo e($formMode); ?>CategoryName" placeholder="Nombre" <?php if(isset($category)): ?> value="<?php echo e($category->name); ?>" <?php endif; ?>>
        </div>
        <div class="col">
            <select class="form-control" id="<?php echo e($formMode); ?>RecipesSelect" name="kk[]" multiple="multiple" style="width: 100%;">
                <?php $__currentLoopData = $recipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recipe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value=<?php echo e($recipe->id); ?> <?php if($attachedRecipes->contains($recipe)): echo 'selected'; endif; ?>><?php echo e($recipe->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
    <div class="row" style="margin-top: 2%;">
        <div class="col-10"></div>
        <div class="col">
            <?php if(isset($category)): ?>
            <button class="btn btn-success" onclick="updateCategory(<?php echo e($category->id); ?>)">Modificar</button>
            <?php else: ?>
            <button class="btn btn-success" onclick="createCategory()">Crear</button>
            <?php endif; ?>
        </div>
    </div>
</div>
<script>
    function createCategory() {
        var recipesToAttach = [];
        var categoryName = $('#insertCategoryName').val();

        $('#insertRecipesSelect').find(':selected').each(function() {
            recipesToAttach.push(this.value);
        });

        var data = {
            "recipesToAttach": recipesToAttach,
            "newName": categoryName
        }

        var settings = {
            "async": true,
            "crossDomain": true,
            "url": "<?php echo e(CategoryRoutes::NEW_CATEGORY); ?>",
            "method": "POST",
            "headers": {
                "cache-control": "no-cache",
                "postman-token": "beeffe31-037f-448b-b45a-382e3b7c8e1c"
            },
            "data": JSON.stringify(data)
        }

        $.ajax(settings).done(function(response) {
            alert('Se ha incluido una categoría nueva al sistema');
            location.reload();
        });
    }

    function updateCategory(id) {
        var recipesToAttach = [];
        var categoryName = $('#updateCategoryName').val();

        $('#updateRecipesSelect').find(':selected').each(function() {
            recipesToAttach.push(this.value);
        });

        var data = {
            "id": id,
            "recipesToAttach": recipesToAttach,
            "newName": categoryName
        }

        var settings = {
            "async": true,
            "crossDomain": true,
            "url": "<?php echo e(CategoryRoutes::UPDATE); ?>",
            "method": "POST",
            "headers": {
                "cache-control": "no-cache",
                "postman-token": "beeffe31-037f-448b-b45a-382e3b7c8e1c"
            },
            "data": JSON.stringify(data)
        }

        $.ajax(settings).done(function(response) {
            alert('Se ha actualizado la categoría en el sistema');
            location.reload();
        });
    }
</script><?php /**PATH /var/www/html/resources/views/components/forms/category.blade.php ENDPATH**/ ?>